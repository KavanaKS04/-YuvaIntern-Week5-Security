YUVAINTERN WEEK 5 - SECURITY ENHANCEMENTS IN PYTHON APPLICATIONS

Files:
- secure_student_app.py: Secure Student Management System
- test_security.py: Automated unittest security checks
- YuvaIntern_Week5_Security_Audit_Report.docx: Security audit report

Requirements:
- Python 3.10+ (tested conceptually for Python 3.13; uses standard library only)

Run the application:
    python secure_student_app.py

Run the tests:
    python -m unittest -v test_security.py

Notes:
- The application creates students.db when it is run.
- The test suite uses a temporary database and should not modify the normal application database.
- Do not store real or sensitive student data in this educational demonstration.
- Authentication, authorization, and database encryption are not implemented; see the report limitations.
